document.getElementById('botForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const botName = document.getElementById('botName').value;
    const botToken = document.getElementById('botToken').value;
    const prefix = document.getElementById('prefix').value;
    const language = document.getElementById('language').value;
    const commandResponses = document.getElementById('commands').value.split('\n').map(line => {
        const parts = line.split(':');
        const command = parts[0].trim();
        const response = (parts[1] || '').trim();
        return { command, response };
    }).filter(item => item.command !== '');

    const features = {
        autoRole: document.getElementById('feature1').checked,
        welcomeMessage: document.getElementById('feature2').checked,
    };

    let generatedCode = '';

    if (language === 'discord.js') {
        generatedCode = `
const { Client, GatewayIntentBits } = require('discord.js');
const client = new Client({ intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildBans,
    GatewayIntentBits.GuildEmojisAndStickers,
    GatewayIntentBits.GuildIntegrations,
    GatewayIntentBits.GuildInvites,
    GatewayIntentBits.GuildMessageReactions,
    GatewayIntentBits.GuildMessageTyping,
    GatewayIntentBits.GuildPresences,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.GuildWebhooks,
    GatewayIntentBits.DirectMessages,
    GatewayIntentBits.DirectMessageReactions,
    GatewayIntentBits.DirectMessageTyping
] });

client.once('ready', () => {
    console.log('${botName} is online!');
});

client.on('messageCreate', message => {
    if (!message.content.startsWith('${prefix}') || message.author.bot) return;

    const args = message.content.slice(${prefix.length}).trim().split(/ +/);
    const command = args.shift().toLowerCase();

    switch (command) {`;

        commandResponses.forEach(({ command, response }) => {
            generatedCode += `
        case '${command}':
            message.channel.send('${response || `You used the ${command} command!`}');
            break;`;
        });

        generatedCode += `
        default:
            message.channel.send('Unknown command!');
    }
});

${features.autoRole ? `
client.on('guildMemberAdd', member => {
    const role = member.guild.roles.cache.find(role => role.name === 'New Member');
    if (role) member.roles.add(role);
});` : ''}

${features.welcomeMessage ? `
client.on('guildMemberAdd', member => {
    const channel = member.guild.channels.cache.find(ch => ch.name === 'welcome');
    if (!channel) return;
    channel.send('Welcome to the server, ' + member.toString() + '!');
});` : ''}

client.login('${botToken}');
        `;
    } else if (language === 'discord.py') {
        generatedCode = `
import discord
from discord.ext import commands

intents = discord.Intents.all()

bot = commands.Bot(command_prefix='${prefix}', intents=intents)

@bot.event
async def on_ready():
    print(f'{bot.user.name} is online!')

${commandResponses.map(({ command, response }) => {
    return `
@bot.command()
async def ${command}(ctx):
    await ctx.send('${response || `You used the ${command} command!`}')`;
}).join('')}

${features.autoRole ? `
@bot.event
async def on_member_join(member):
    role = discord.utils.get(member.guild.roles, name='New Member')
    if role:
        await member.add_roles(role)
` : ''}

${features.welcomeMessage ? `
@bot.event
async def on_member_join(member):
    channel = discord.utils.get(member.guild.channels, name='welcome')
    if channel:
        await channel.send('Welcome to the server, ' + member.mention + '!')
` : ''}

bot.run('${botToken}')
        `;
    }

    document.getElementById('generatedCode').textContent = generatedCode;
});

document.getElementById('generatedCode').addEventListener('click', function() {
    const code = this.textContent;
    navigator.clipboard.writeText(code).then(() => {
        alert('Code copied to clipboard!');
    });
});

document.getElementById('themeToggle').addEventListener('click', function() {
    document.body.classList.toggle('dark-mode');
});
